// let contador = 0
// let res = document.querySelector('section#result')
// function contar() {
//     contador++
//     res.innerHTML = `<p>O contador está em <strong>${contador} </strong>cliques</p>`
// }

// function zerar() {
//     contador = 0
//     res.innerHTML = null
// }

// function calcular() {
//     let num = Number(window.prompt('Digite um número:'))

//     let res = document.querySelector('section#result')
//     res.interHTML = `<p>O número a ser analisdado aqui será o<strong>${num}</strong></p>`

//     res.inerHTML += `<p>O seu valor absoluto é <strong>${Math.abs(num)} </strong></p>`

//     res.inerHTML += `<p>A sua parte inteira é${Math.trunc(num)}</p>`

//     res.innerHTML += `<p> O seu valor inteiro mais próximo é${Math.trunc(num)}</p>`

//     res.inerHTML += `<p>A sua raiz quadrada é ${Math.sqrt(num)}</p>`

//     res.inerHTML += `<p>A sua raíz cúbica é ${Math.cbrt(num)}</p>`

//     res.inerHTML += `<p> O valor de ${num}<sup>2</sup> é ${Math.pow(num,2)} </p>`

//     res.inerHTML += `<p> O valor de ${num}<sup3</sup> é ${Math.pow(num,3)} </p>`
// }

function calculo() {
    let a = Number(document.getElementById('a').value);
    let b = Number(document.getElementById('b').value);
    let c = Number(document.getElementById('c').value);

    document.querySelector('#result').innerHTML = `A soma de a <mark>${a} + ${b}</mark> dividido por <strong>${c} </strong> igual a <strong>${(a + b / c)}</strong>`
}