let resp = window.document.getElementById('saida')
function acao1() {
    resp.innerHTML += '<p>Clicou no primeiro botao'
}

function acao2() {
    resp.innerHTML += '<p>Clicou no segundo botao'
}

function acao3() {
    resp.innerHTML += '<p>Clicou no terceiro botao'
}

function acao4() {
    resp.innerHTML += '<p>Clicou no quarto botao'
}