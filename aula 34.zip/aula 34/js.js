document.getElementById('loginForm').addEventListener('submit', function (event)){
    event.preventDefault();
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    if (username  === 'admin' && password=== 'admin') {
        document.getElementById('message').textContent = 'Login efetuado com sucesso!';
    } else {
        document.getElementById('message').textContent = 'Credenciais inválidas!';
    }
}